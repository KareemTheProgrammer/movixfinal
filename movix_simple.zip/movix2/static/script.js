async function initNav() {
    const res = await fetch('/api/me/');
    const data = await res.json();

    if (data.username) {
        document.getElementById('wl-count').textContent = data.count;
        document.getElementById('nav-username').textContent = `Hi, ${data.username}`;
        document.getElementById('btn-logout').style.display = 'inline';
        document.getElementById('btn-login').style.display = 'none';
    }
}

initNav();
