from django.urls import path
from . import views

urlpatterns = [
    path('', views.home),
    path('watchlist/', views.watchlist_page),
    path('auth/', views.auth_page),
    path('logout/', views.logout_view),
    path('seed/', views.seed),

    path('api/me/', views.me),
    path('api/movies/', views.movies_api),
    path('api/watchlist/', views.watchlist_api),
    path('api/login/', views.login_view),
    path('api/register/', views.register_view),
    path('api/watchlist/add/', views.add_to_watchlist),
    path('api/watchlist/remove/<int:movie_id>/', views.remove_from_watchlist),
    path('api/recommend/', views.recommend),
]
