import json
import re
import requests
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from .models import Movie, WatchlistItem

MOVIES = [
    {"title": "The Avengers", "genre": "Action", "rating": 8.0, "year": 2012, "description": "Earth's mightiest heroes unite to stop Loki from enslaving humanity.", "poster": "https://www.vintagemovieposters.co.uk/wp-content/uploads/2023/03/IMG_1887-scaled.jpeg"},
    {"title": "Inception", "genre": "Action", "rating": 8.8, "year": 2010, "description": "A thief who steals secrets through dreams is given one last impossible job.", "poster": "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_.jpg"},
    {"title": "Dune", "genre": "Action", "rating": 8.0, "year": 2021, "description": "A noble family fights for control of the most valuable planet in the universe.", "poster": "https://preview.redd.it/what-has-happened-to-movie-posters-v0-veyma8wnnhb81.jpg?width=640&crop=smart&auto=webp&s=3155408077eb1f8e3f8c4566b44e51204bc09ba9"},
    {"title": "Guardians of the Galaxy", "genre": "Action", "rating": 8.0, "year": 2014, "description": "A group of intergalactic criminals team up to stop a villain with plans to destroy the universe.", "poster": "https://www.vintagemovieposters.co.uk/wp-content/uploads/2020/11/IMG_5878-scaled.jpeg"},
    {"title": "The Godfather", "genre": "Drama", "rating": 9.2, "year": 1972, "description": "A crime dynasty patriarch passes control of his empire to his reluctant son.", "poster": "https://m.media-amazon.com/images/M/MV5BNGEwYjgwOGQtYjg5ZS00Njc1LTk2ZGEtM2QwZWQ2NjdhZTE5XkEyXkFqcGc@._V1_.jpg"},
    {"title": "Joker", "genre": "Drama", "rating": 8.4, "year": 2019, "description": "A troubled comedian's descent into madness gives birth to Gotham's most dangerous villain.", "poster": "https://www.tallengestore.com/cdn/shop/products/Joker_-_Put_On_A_Happy_Face_-_Joaquin_Phoenix_-_Hollywood_English_Movie_Poster_3_7e3b9089-6103-4ff5-9075-23c552350d21.jpg"},
    {"title": "Walk the Line", "genre": "Drama", "rating": 7.8, "year": 2005, "description": "The story of Johnny Cash's rise to fame and his love for June Carter.", "poster": "https://static.wikia.nocookie.net/filmguide/images/5/5a/Walk_the_line_poster.jpg/revision/latest?cb=20160330172423"},
    {"title": "The Aviator", "genre": "Drama", "rating": 7.5, "year": 2004, "description": "Howard Hughes builds a film empire while battling obsessive-compulsive disorder.", "poster": "https://tse1.mm.bing.net/th/id/OIP.hh1yOBYZie4HzI6BP-N-KgHaLH?rs=1&pid=ImgDetMain&o=7&rm=3"},
    {"title": "Home Alone", "genre": "Comedy", "rating": 7.7, "year": 1990, "description": "A boy accidentally left home alone must defend his house from bumbling burglars.", "poster": "https://www.movieposters.com/cdn/shop/files/homealone.124915.jpg?v=1762475830&width=1024"},
    {"title": "Little Miss Sunshine", "genre": "Comedy", "rating": 7.9, "year": 2006, "description": "A dysfunctional family piles into a van to drive their daughter to a beauty pageant.", "poster": "https://i.pinimg.com/originals/58/77/bd/5877bdfaf95cd4286c4d894bb042d511.jpg"},
    {"title": "Happy Gilmore", "genre": "Comedy", "rating": 7.0, "year": 1996, "description": "A failed hockey player discovers a talent for golf and enters the tour to save his grandma's house.", "poster": "https://i.ebayimg.com/images/g/mkIAAOSwEIlnp8OA/s-l1600.webp"},
    {"title": "US", "genre": "Horror", "rating": 6.8, "year": 2019, "description": "A family's beach vacation is shattered when their sinister doppelgängers show up.", "poster": "https://www.indiewire.com/wp-content/uploads/2019/12/us-1.jpg?w=758"},
    {"title": "Insidious", "genre": "Horror", "rating": 6.8, "year": 2010, "description": "A family tries to save their comatose son from evil spirits in a dark astral dimension.", "poster": "https://image.tmdb.org/t/p/original/4TKCqUqZtNI1VNnXHkznQBH7JXK.jpg"},
    {"title": "Evil Dead 2", "genre": "Horror", "rating": 7.7, "year": 1987, "description": "A man fights for survival against demonic forces in a remote cabin in the woods.", "poster": "https://m.media-amazon.com/images/M/MV5BMGMxMWVhMzAtYWRlOS00YzY1LTlkYTQtYjU5ZDM4MGI1YWFjXkEyXkFqcGc@._V1_.jpg"},
    {"title": "Sinners", "genre": "Horror", "rating": 7.0, "year": 2025, "description": "Twin brothers return home to escape their past and find something far darker waiting.", "poster": "https://famousmovieposters.co.uk/cdn/shop/files/Sinners_Original_Movie_Poster_Cropped_Framed-min.jpg?v=1757528225&width=600"},
    {"title": "Jurassic Park", "genre": "Adventure", "rating": 8.2, "year": 1993, "description": "A billionaire's theme park of cloned dinosaurs goes catastrophically wrong.", "poster": "https://img.buzzfeed.com/buzzfeed-static/static/2022-04/4/20/asset/0f12255e2129/sub-buzz-817-1649105149-10.jpg?downsize=700%3A%2A&output-quality=auto&output-format=auto"},
    {"title": "Jaws", "genre": "Adventure", "rating": 8.1, "year": 1975, "description": "A great white shark terrorizes a beach town and three men set out to hunt it down.", "poster": "https://images.photowall.com/products/51078/movie-poster-jaws.jpg?h=699&q=85"},
    {"title": "Avatar", "genre": "Adventure", "rating": 7.5, "year": 2009, "description": "A paralyzed marine is sent to the alien moon Pandora and ends up fighting for its people.", "poster": "https://i.ebayimg.com/images/g/bvcAAOSw5jtjkqdA/s-l1600.webp"},
    {"title": "Scream VII", "genre": "Horror", "rating": 7.0, "year": 2026, "description": "A new Ghostface killer targets the survivors of the previous Scream films.", "poster": "https://i.ebayimg.com/images/g/gu0AAeSwIWtpglr-/s-l1600.webp"},
    {"title": "The Witch", "genre": "Horror", "rating": 7.0, "year": 2015, "description": "A Puritan family in 1630s New England is torn apart by witchcraft and dark forces.", "poster": "https://static1.moviewebimages.com/wordpress/wp-content/uploads/movie/xCtP4wGFdf88LZMaer5W47eZC7GkEz.jpg"},
]


def home(request):
    return render(request, 'home.html')


def watchlist_page(request):
    if not request.user.is_authenticated:
        return redirect('/auth/')
    return render(request, 'watchlist.html')


def auth_page(request):
    return render(request, 'auth.html')


def logout_view(request):
    logout(request)
    return redirect('/auth/')


def seed(request):
    if Movie.objects.exists():
        return JsonResponse({'msg': 'Already seeded'})
    for m in MOVIES:
        Movie.objects.create(**m)
    return JsonResponse({'msg': f'Added {len(MOVIES)} movies'})


def me(request):
    if request.user.is_authenticated:
        count = WatchlistItem.objects.filter(user=request.user).count()
        return JsonResponse({'username': request.user.username, 'count': count})
    return JsonResponse({'username': None, 'count': 0})


def movies_api(request):
    qs = Movie.objects.all()
    if request.GET.get('search'):
        qs = qs.filter(title__icontains=request.GET['search'])
    if request.GET.get('genre'):
        qs = qs.filter(genre=request.GET['genre'])
    data = list(qs.values('id', 'title', 'genre', 'rating', 'year', 'description', 'poster'))
    return JsonResponse({'movies': data})


def watchlist_api(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Login required'}, status=401)
    items = WatchlistItem.objects.filter(user=request.user).select_related('movie')
    data = [{'id': i.movie.id, 'title': i.movie.title, 'genre': i.movie.genre,
             'rating': i.movie.rating, 'year': i.movie.year, 'poster': i.movie.poster} for i in items]
    return JsonResponse({'watchlist': data})


@csrf_exempt
def login_view(request):
    body = json.loads(request.body)
    user = authenticate(username=body['username'], password=body['password'])
    if user:
        login(request, user)
        return JsonResponse({'ok': True})
    return JsonResponse({'error': 'Wrong username or password'}, status=400)


@csrf_exempt
def register_view(request):
    body = json.loads(request.body)
    if User.objects.filter(username=body['username']).exists():
        return JsonResponse({'error': 'Username already taken'}, status=400)
    user = User.objects.create_user(body['username'], password=body['password'])
    login(request, user)
    return JsonResponse({'ok': True})


@csrf_exempt
def add_to_watchlist(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Login required'}, status=401)
    body = json.loads(request.body)
    movie = Movie.objects.get(id=body['id'])
    WatchlistItem.objects.get_or_create(user=request.user, movie=movie)
    count = WatchlistItem.objects.filter(user=request.user).count()
    return JsonResponse({'count': count})


@csrf_exempt
def remove_from_watchlist(request, movie_id):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Login required'}, status=401)
    WatchlistItem.objects.filter(user=request.user, movie_id=movie_id).delete()
    count = WatchlistItem.objects.filter(user=request.user).count()
    return JsonResponse({'count': count})


@csrf_exempt
def recommend(request):
    body = json.loads(request.body)
    genre = body.get('genre', 'Action')

    if settings.GEMINI_API_KEY == 'YOUR_API_KEY_HERE':
        fallback = [
            {'title': 'The Dark Knight', 'year': 2008, 'rating': 9.0, 'description': 'Batman faces the Joker, a criminal who wants to plunge Gotham into anarchy.'},
            {'title': 'Interstellar', 'year': 2014, 'rating': 8.6, 'description': 'A team of astronauts travel through a wormhole to find a new home for humanity.'},
            {'title': 'Parasite', 'year': 2019, 'rating': 8.5, 'description': 'A poor family schemes to become employed by a wealthy household.'},
            {'title': 'The Shawshank Redemption', 'year': 1994, 'rating': 9.3, 'description': 'Two men bond in prison and find hope and redemption over the years.'},
            {'title': 'Fight Club', 'year': 1999, 'rating': 8.8, 'description': 'An insomniac forms an underground fight club with a soap salesman.'},
        ]
        return JsonResponse({'movies': fallback})

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={settings.GEMINI_API_KEY}"
    prompt = f"Recommend 5 {genre} movies. Return only a JSON array. Each item must have: title, year, rating (out of 10), description (one sentence). No markdown, no extra text."

    response = requests.post(url, json={"contents": [{"parts": [{"text": prompt}]}]}, timeout=15)
    text = response.json()['candidates'][0]['content']['parts'][0]['text']
    match = re.search(r'\[.*?\]', text, re.DOTALL)
    return JsonResponse({'movies': json.loads(match.group())})
